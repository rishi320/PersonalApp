import * as types from "../tasks";

const initialState = {
  todos: [
    {
      text: "some todo 1",
      completed: false,
      remainder: false,
    },
    {
      text: "some todo 2",
      completed: false,
      remainder: false,
    },
  ],
};

export default function reducer(state = initialState, action) {
  switch (action.type) {
    case types.GET_TODO_LIST_SUCCESS: {
      return {
        ...state,
      };
    }

    case types.ADD_TODO_LIST_SUCCESS: {
      return {
        ...state,
        todos: [
          ...state.todos,
          {
            text: action.payload,
            completed: false,
            remainder: false,
          },
        ],
      };
    }
  }
}
